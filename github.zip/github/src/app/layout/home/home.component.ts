import { Component, OnInit } from '@angular/core';
import * as AOS from 'aos';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  mySlideImages: any;
  mySlideOptions: any;
  catMenImages: any;
  catMenOptions: any;
  returnedArray: string[];


  constructor() {
 
   }

  ngOnInit(): void {
    AOS.init();
    this.owlCarouselSlider();
    this.menSlider();
  }

  owlCarouselSlider(){
    this.mySlideImages = [
      '../../../assets/images/banner.jpg',
      '../../../assets/images/banner2.jpg',
      '../../../assets/images/banner3.jpg'
    ];
    this.mySlideOptions={items: 1, dots: false, nav: true, loop:true, autoplay:true, animateOut: 'fadeOut', responsive: { '0': { nav: false, dots: true}, '1200': { nav: true, dots: false}}};
  }

  menSlider(){
    this.catMenImages = [
      {
        'img':'../../../assets/images/m1.jpg',
        'title': 'Shoe tilte 1',
      },
      {
        'img':'../../../assets/images/m2.jpg',
        'title': 'Shoe tilte 2',
      },
      {
        'img':'../../../assets/images/g1.jpg',
        'title': 'Shoe tilte 3',
      },
      {
        'img':'../../../assets/images/g2.jpg',
        'title': 'Shoe tilte 4',
      },
      {
        'img':'../../../assets/images/k1.jpg',
        'title': 'Shoe tilte 5',
      },
      {
        'img':'../../../assets/images/k2.jpg',
        'title': 'Shoe tilte 6',
      },
      {
        'img':'../../../assets/images/m1.jpg',
        'title': 'Shoe tilte 1',
      },
      {
        'img':'../../../assets/images/m2.jpg',
        'title': 'Shoe tilte 2',
      },
      {
        'img':'../../../assets/images/g1.jpg',
        'title': 'Shoe tilte 3',
      },
      {
        'img':'../../../assets/images/g2.jpg',
        'title': 'Shoe tilte 4',
      },
      {
        'img':'../../../assets/images/k1.jpg',
        'title': 'Shoe tilte 5',
      },
      {
        'img':'../../../assets/images/k2.jpg',
        'title': 'Shoe tilte 6',
      },
      {
        'img':'../../../assets/images/m1.jpg',
        'title': 'Shoe tilte 1',
      },
      {
        'img':'../../../assets/images/m2.jpg',
        'title': 'Shoe tilte 2',
      },
      {
        'img':'../../../assets/images/g1.jpg',
        'title': 'Shoe tilte 3',
      },
      {
        'img':'../../../assets/images/g2.jpg',
        'title': 'Shoe tilte 4',
      },
      {
        'img':'../../../assets/images/k1.jpg',
        'title': 'Shoe tilte 5',
      },
      {
        'img':'../../../assets/images/k2.jpg',
        'title': 'Shoe tilte 6',
      },
      {
        'img':'../../../assets/images/m1.jpg',
        'title': 'Shoe tilte 1',
      },
      {
        'img':'../../../assets/images/m2.jpg',
        'title': 'Shoe tilte 2',
      },
      {
        'img':'../../../assets/images/g1.jpg',
        'title': 'Shoe tilte 3',
      },
      {
        'img':'../../../assets/images/g2.jpg',
        'title': 'Shoe tilte 4',
      },
      {
        'img':'../../../assets/images/k1.jpg',
        'title': 'Shoe tilte 5',
      },
      {
        'img':'../../../assets/images/k2.jpg',
        'title': 'Shoe tilte 6',
      }
    ];

    this.returnedArray = this.catMenImages.slice(0, 9);
  
  }

  pageChanged(event: PageChangedEvent): void {
    const startItem = (event.page - 1) * event.itemsPerPage;
    const endItem = event.page * event.itemsPerPage;
    this.returnedArray = this.catMenImages.slice(startItem, endItem);
  }

}
