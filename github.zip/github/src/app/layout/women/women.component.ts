import { Component, OnInit } from '@angular/core';
import * as AOS from 'aos';
@Component({
  selector: 'app-women',
  templateUrl: './women.component.html',
  styleUrls: ['./women.component.scss']
})
export class WomenComponent implements OnInit {
  catMenImages: any;
  constructor() { }

  ngOnInit(): void {
    AOS.init();
    this.menSlider();
  }

  menSlider(){
    this.catMenImages = [
      {
        'img':'../../../assets/images/m1.jpg',
        'title': 'Shoe tilte 1',
      },
      {
        'img':'../../../assets/images/m2.jpg',
        'title': 'Shoe tilte 2',
      },
      {
        'img':'../../../assets/images/g1.jpg',
        'title': 'Shoe tilte 3',
      },
      {
        'img':'../../../assets/images/g2.jpg',
        'title': 'Shoe tilte 4',
      },
      {
        'img':'../../../assets/images/k1.jpg',
        'title': 'Shoe tilte 5',
      },
      {
        'img':'../../../assets/images/k2.jpg',
        'title': 'Shoe tilte 6',
      },
      {
        'img':'../../../assets/images/m1.jpg',
        'title': 'Shoe tilte 1',
      },
      {
        'img':'../../../assets/images/m2.jpg',
        'title': 'Shoe tilte 2',
      },
      {
        'img':'../../../assets/images/g1.jpg',
        'title': 'Shoe tilte 3',
      },
      {
        'img':'../../../assets/images/g2.jpg',
        'title': 'Shoe tilte 4',
      },
      {
        'img':'../../../assets/images/k1.jpg',
        'title': 'Shoe tilte 5',
      },
      {
        'img':'../../../assets/images/k2.jpg',
        'title': 'Shoe tilte 6',
      },
      {
        'img':'../../../assets/images/m1.jpg',
        'title': 'Shoe tilte 1',
      },
      {
        'img':'../../../assets/images/m2.jpg',
        'title': 'Shoe tilte 2',
      },
      {
        'img':'../../../assets/images/g1.jpg',
        'title': 'Shoe tilte 3',
      },
      {
        'img':'../../../assets/images/g2.jpg',
        'title': 'Shoe tilte 4',
      },
      {
        'img':'../../../assets/images/k1.jpg',
        'title': 'Shoe tilte 5',
      },
      {
        'img':'../../../assets/images/k2.jpg',
        'title': 'Shoe tilte 6',
      },
      {
        'img':'../../../assets/images/m1.jpg',
        'title': 'Shoe tilte 1',
      },
      {
        'img':'../../../assets/images/m2.jpg',
        'title': 'Shoe tilte 2',
      },
      {
        'img':'../../../assets/images/g1.jpg',
        'title': 'Shoe tilte 3',
      },
      {
        'img':'../../../assets/images/g2.jpg',
        'title': 'Shoe tilte 4',
      },
      {
        'img':'../../../assets/images/k1.jpg',
        'title': 'Shoe tilte 5',
      },
      {
        'img':'../../../assets/images/k2.jpg',
        'title': 'Shoe tilte 6',
      }
    ];

  
  }


}
