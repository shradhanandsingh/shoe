import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactComponent } from './layout/contact/contact.component';
import { HomeComponent } from './layout/home/home.component';


const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent
  },
  { path: '',   redirectTo: '/home', pathMatch: 'full' },
  { 
    path: 'men', 
    loadChildren: () => import('./layout/men/men.module').then(m => m.MenModule) 
  },
  { path: 'women', loadChildren: () => import('./layout/women/women.module').then(m => m.WomenModule) },
  { path: 'kids', loadChildren: () => import('./layout/kids/kids.module').then(m => m.KidsModule) },
  {
    path: 'contact', component: ContactComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
